$(document).ready(()=>{
    $(".btnUpdate").click((e)=>{
        
       let categoryName= $(e.target).parent().siblings()[0].textContent;
       let categoryImage=$(e.target).parent().siblings()[1].children[0].getAttribute("src").split("/")[1];
       $("#updateCategoryName").val(categoryName.trim());
       $("#customFile1").siblings(".custom-file-label").addClass("selected").html(categoryImage);
       $("#customFile1").siblings(".hidden").attr("value",false);
       $("#customFile1").change(()=>{
        $("#customFile1").siblings(".hidden").attr("value",true);
       });
    })
});
